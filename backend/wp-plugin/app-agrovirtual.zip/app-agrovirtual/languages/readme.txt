Create a file POT, PO and MO using POEdit or Loco Translate Plugin, 
then rename accordance with textdomain used by the plugin, as follows:
* app_agrovirtual-de_DE.po
* app_agrovirtual-id_ID.po
* app_agrovirtual_ES.po
* app_agrovirtual-en_US.po
* app_agrovirtual-de_DE.mo
* app_agrovirtual-id_ID.mo
* app_agrovirtual-es_ES.mo
* app_agrovirtual-en_US.mo
Download:
* http://wordpress.org/extend/plugins/loco-translate
* http://poedit.net/download
